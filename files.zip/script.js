// Simple Pong game
(() => {
  const canvas = document.getElementById('gameCanvas');
  const ctx = canvas.getContext('2d');

  const W = canvas.width;
  const H = canvas.height;

  // Game objects
  const paddle = {
    width: 12,
    height: 90,
    speed: 6,
    y: (H - 90) / 2,
  };
  const leftPaddle = { x: 20, ...paddle };
  const rightPaddle = { x: W - 20 - paddle.width, ...paddle, speed: 5 };

  const ball = {
    x: W / 2,
    y: H / 2,
    r: 8,
    speed: 5,
    dx: 5,
    dy: 3
  };

  let leftScore = 0;
  let rightScore = 0;
  const leftScoreEl = document.getElementById('leftScore');
  const rightScoreEl = document.getElementById('rightScore');

  // Input state
  const keys = { ArrowUp: false, ArrowDown: false };
  let paused = false;

  // Utility
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  // Reset ball to center and aim toward the player who conceded a point
  function resetBall(direction = 1) {
    ball.x = W / 2;
    ball.y = H / 2;
    ball.speed = 5;
    const angle = (Math.random() * Math.PI / 4) - (Math.PI / 8); // -22.5deg..+22.5deg
    ball.dx = direction * ball.speed * Math.cos(angle);
    ball.dy = ball.speed * Math.sin(angle);
  }

  // Draw functions
  function drawRect(x, y, w, h, color = '#fff') {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, w, h);
  }

  function drawNet() {
    ctx.fillStyle = 'rgba(255,255,255,0.06)';
    const seg = 10;
    const gap = 12;
    const cx = W / 2 - 1;
    for (let y = 0; y < H; y += seg + gap) {
      ctx.fillRect(cx, y, 2, seg);
    }
  }

  function drawBall() {
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.arc(ball.x, ball.y, ball.r, 0, Math.PI * 2);
    ctx.fill();
  }

  function draw() {
    // clear
    ctx.clearRect(0, 0, W, H);
    // background gradient already set by CSS, but draw dark overlay slightly in canvas
    ctx.fillStyle = 'rgba(0,0,0,0.06)';
    ctx.fillRect(0, 0, W, H);

    drawNet();
    drawRect(leftPaddle.x, leftPaddle.y, leftPaddle.width, leftPaddle.height);
    drawRect(rightPaddle.x, rightPaddle.y, rightPaddle.width, rightPaddle.height);
    drawBall();
  }

  // Collision detection between ball and paddle
  function paddleCollides(p, b) {
    return b.x - b.r < p.x + p.width &&
           b.x + b.r > p.x &&
           b.y - b.r < p.y + p.height &&
           b.y + b.r > p.y;
  }

  // Update game state
  function update() {
    if (paused) return;

    // Move left paddle by keys
    if (keys.ArrowUp) leftPaddle.y -= leftPaddle.speed;
    if (keys.ArrowDown) leftPaddle.y += leftPaddle.speed;
    // Clamp
    leftPaddle.y = clamp(leftPaddle.y, 0, H - leftPaddle.height);

    // Move right paddle (simple AI: follow ball with max speed)
    const centerRight = rightPaddle.y + rightPaddle.height / 2;
    const diff = ball.y - centerRight;
    const aiSpeed = rightPaddle.speed;
    if (Math.abs(diff) > 6) {
      rightPaddle.y += Math.sign(diff) * Math.min(aiSpeed, Math.abs(diff));
      rightPaddle.y = clamp(rightPaddle.y, 0, H - rightPaddle.height);
    }

    // Ball movement
    ball.x += ball.dx;
    ball.y += ball.dy;

    // Wall collisions
    if (ball.y - ball.r <= 0) {
      ball.y = ball.r;
      ball.dy *= -1;
    } else if (ball.y + ball.r >= H) {
      ball.y = H - ball.r;
      ball.dy *= -1;
    }

    // Paddle collisions
    if (paddleCollides(leftPaddle, ball) && ball.dx < 0) {
      // reflect
      ball.x = leftPaddle.x + leftPaddle.width + ball.r;
      ball.dx *= -1;
      // change dy depending on hit spot
      const hitPos = (ball.y - (leftPaddle.y + leftPaddle.height / 2)) / (leftPaddle.height / 2);
      ball.dy = hitPos * (ball.speed + 1);
      // increase speed a bit
      ball.speed *= 1.05;
      ball.dx = Math.sign(ball.dx) * ball.speed;
    } else if (paddleCollides(rightPaddle, ball) && ball.dx > 0) {
      ball.x = rightPaddle.x - ball.r;
      ball.dx *= -1;
      const hitPos = (ball.y - (rightPaddle.y + rightPaddle.height / 2)) / (rightPaddle.height / 2);
      ball.dy = hitPos * (ball.speed + 1);
      ball.speed *= 1.05;
      ball.dx = Math.sign(ball.dx) * ball.speed;
    }

    // Scoring
    if (ball.x + ball.r < 0) {
      // right scores
      rightScore++;
      rightScoreEl.textContent = rightScore;
      resetBall(-1); // serve toward left player
    } else if (ball.x - ball.r > W) {
      // left scores
      leftScore++;
      leftScoreEl.textContent = leftScore;
      resetBall(1); // serve toward right
    }
  }

  // Game loop
  function loop() {
    update();
    draw();
    requestAnimationFrame(loop);
  }

  // Input handlers
  canvas.addEventListener('mousemove', (e) => {
    const rect = canvas.getBoundingClientRect();
    const y = e.clientY - rect.top;
    // center paddle on mouse y
    leftPaddle.y = clamp(y - leftPaddle.height / 2, 0, H - leftPaddle.height);
  });

  window.addEventListener('keydown', (e) => {
    if (e.key === ' ') {
      paused = !paused;
      e.preventDefault();
      return;
    }
    if (e.key === 'r' || e.key === 'R') {
      // reset scores
      leftScore = 0;
      rightScore = 0;
      leftScoreEl.textContent = leftScore;
      rightScoreEl.textContent = rightScore;
      resetBall(Math.random() < 0.5 ? 1 : -1);
    }
    if (e.key in keys) keys[e.key] = true;
  });

  window.addEventListener('keyup', (e) => {
    if (e.key in keys) keys[e.key] = false;
  });

  // Touch support: move left paddle by touch
  canvas.addEventListener('touchmove', (e) => {
    e.preventDefault();
    const touch = e.touches[0];
    const rect = canvas.getBoundingClientRect();
    const y = touch.clientY - rect.top;
    leftPaddle.y = clamp(y - leftPaddle.height / 2, 0, H - leftPaddle.height);
  }, {passive:false});

  // Initialize
  resetBall(Math.random() < 0.5 ? 1 : -1);
  leftScoreEl.textContent = leftScore;
  rightScoreEl.textContent = rightScore;

  // Start game loop
  requestAnimationFrame(loop);
})();